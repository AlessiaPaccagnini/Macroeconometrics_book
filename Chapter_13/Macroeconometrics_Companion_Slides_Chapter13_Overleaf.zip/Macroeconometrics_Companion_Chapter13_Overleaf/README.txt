Macroeconometrics Companion Slides - Chapter 13
Alessia Paccagnini, De Gruyter, 2026

Upload this folder (or the ZIP) to Overleaf and compile main.tex with pdfLaTeX.
Original Chapter 13 figures from the book source are included in figures/ to preserve quality.
The slides are intended as an editable teaching starting point.
