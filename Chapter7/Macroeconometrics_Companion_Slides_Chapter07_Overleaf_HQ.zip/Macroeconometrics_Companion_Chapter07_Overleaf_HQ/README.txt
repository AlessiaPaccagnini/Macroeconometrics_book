Macroeconometrics Companion Slides - Chapter 7: Forecasting
Alessia Paccagnini, De Gruyter, 2026

Upload this folder (or the ZIP archive) to Overleaf and compile main.tex with pdfLaTeX.
The slides are designed as an editable teaching starting point. Users are encouraged to add their own examples, exercises, datasets and coding demonstrations.
