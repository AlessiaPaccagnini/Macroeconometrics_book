Macroeconometrics - Companion Slides, Chapter 10
Alessia Paccagnini, De Gruyter, 2026

Upload this folder (or the ZIP) to Overleaf and compile main.tex with pdfLaTeX.
Original high-resolution/vector figures from the book source are included in figures/.
These slides are an editable teaching starting point and are not a substitute for the full chapter.
