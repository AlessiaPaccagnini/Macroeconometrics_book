function [lik,fprob,m1,m2,sigma1,sigma2]=hamiltonfilterMLAR(THETA,y,x,N,L)
NN=N*(N*L+1);
NN1=(N*(N+1))/2;
 beta1=reshape(THETA(1:NN,:),N*L+1,N);
 beta2=reshape(THETA(NN+1:NN*2,:),N*L+1,N);
[m1,m2]=getmeans(THETA(1:NN,:),THETA(NN+1:NN*2,:),N,L);
A1=chofac1(N,THETA((NN*2)+1:(NN*2)+NN1))';
% A2=chofac1(N,THETA((NN*2)+NN1+1:end-2))';
sigma1=A1'*A1;
sigma2=sigma1;
g2=THETA(rows(THETA));
g1=THETA(rows(THETA)-1);
p=exp(g1)/(1+exp(g1));
q=exp(g2)/(1+exp(g2));
T=rows(y);
isig1=invpd(sigma1);
isig2=invpd(sigma2);
dsig1=det(sigma1);
dsig2=det(sigma2);
%*******************************************step 2 initialise for filter(ergodic probabiltites)r************************************@
%transition probability matrix

    pr_tr=[p(1) (1-q(1)); (1-p(1)) q(1)];

A = [(eye(2)-pr_tr);ones(1,2)];
if isnan(A)
     ett=[0.5;0.5];
 end
    
 EN=[0;0;1];
 ett= pinv(A'*A)*A'*EN;
 if isnan(ett)==1;
 ett=[0.5;0.5];
 end

%**************************************************Step 1 Filter Forward Iteration*****************@
lik=0;
fprob=zeros(T,2);
for it=1:T
pr_tr=[p(1) (1-q(1)); (1-p(1)) q(1)];
em1=y(it,:)-x(it,:)*beta1;
em2=y(it,:)-x(it,:)*beta2;
neta1=(1/sqrt(dsig1))*exp(-0.5*(em1*isig1*em1'));%F(Y\S=1)
neta2=(1/sqrt(dsig2))*exp(-0.5*(em2*isig2*em2'));%F(Y\S=2)

%hamilton filter kim and Nelson eq 4.19 and 4.20 pg63 also see equations 22.4.5 and 22.4.6 in Hamilton
ett1=ett.*([neta1;neta2]);
fit=sum(ett1);
ett=(pr_tr*ett1)/fit;
fprob(it,:)=(ett1./fit)';
if fit>0
    lik=lik+log(fit);
else
    lik=lik-10;
end
    
end
lik=-lik;