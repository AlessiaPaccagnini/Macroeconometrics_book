function estimatemvar(file,VarBench,dirname,fdirname,HORZ,REPS,BURN,Update,MaxTrys,vars)


% Redefine paras (just to use shorter names):
L       = VarBench.L;
lamdaP  = VarBench.lamdaP;
tauP    = VarBench.tauP;
epsilonP= VarBench.epsilonP;


% Get input data    


% Get input data    
fname=strcat(dirname,'data',num2str(file),'.mat');
fname1=strcat(fdirname,'forecast',num2str(file),'.mat'); %name of file to save forecast density
load(fname);
data=datapackr(:,vars);

Y=data;
N=cols(Y);
%take lags
X=[];
for j=1:L
X=[X lag0(data,j) ];
end
X=[X ones(rows(X),1)];
Y=Y(L+1:end,:);
X=X(L+1:end,:);

% Additional priors for VAR coefficients
muP=mean(Y)';
sigmaP=[];
deltaP=[];
e0=[];
for i=1:N
    ytemp=Y(:,i);
    xtemp=[lag0(ytemp,1) ones(rows(ytemp),1)];
    ytemp=ytemp(2:end,:);
    xtemp=xtemp(2:end,:);
    btemp=xtemp\ytemp;
    etemp=ytemp-xtemp*btemp;
    stemp=etemp'*etemp/rows(ytemp);
    if abs(btemp(1))>1
        btemp(1)=1;
    end
    deltaP=[deltaP;btemp(1)];
    sigmaP=[sigmaP;stemp];
    e0=[e0 etemp];
end

%dummy data to implement priors see http://ideas.repec.org/p/ecb/ecbwps/20080966.html
[yd,xd] = create_dummies(lamdaP,tauP,deltaP,epsilonP,L,muP,sigmaP,N);


T=rows(Y);


fsave=zeros(REPS-BURN,HORZ,N); 
jgibbs=1;

% Display empty line (to separate samples in the screen shot)
disp(sprintf(' ')) 


  Y0=[Y;yd];
  X0=[X;xd];
  %conditional mean of the VAR coefficients
  mstar=vec(X0\Y0);  %ols on the appended data
  xx=X0'*X0;
  ixx=xx\eye(cols(xx));  %inv(X0'X0) to be used later in the Gibbs sampling algorithm
  sigma=eye(N); %starting value for sigma
  beta0=vec(X0\Y0);
  igibbs=1;
  jgibbs=0;
while jgibbs<REPS-BURN
	
    % Display progress:
    if mod(igibbs,Update)==0 
        disp(sprintf(' Sample %s    Replication %s of %s.', ... 
            num2str(file), num2str(igibbs), num2str(REPS)));
    end
        
    
     %step 1: Sample VAR coefficients
     [ beta2,PROBLEM] = getcoef( mstar,sigma,ixx,MaxTrys,N,L );
     if PROBLEM
         beta2=beta0;
     else
         beta0=beta2;
     end
     
     %draw covariance
     e=Y0-X0*reshape(beta2,N*L+1,N);
    scale=e'*e;
    sigma=iwpq(T+rows(yd),inv(scale));

     if igibbs>BURN && ~PROBLEM
         jgibbs=jgibbs+1;
         % Simulate and store forward paths:
         yhat = get_pathsVAR(N, HORZ, T, L, Y, beta2,sigma);
         fsave(jgibbs,:,:)=yhat(L+1:end,:);
         
         
     end
     igibbs=igibbs+1;
end

save(fname1,'fsave');

end