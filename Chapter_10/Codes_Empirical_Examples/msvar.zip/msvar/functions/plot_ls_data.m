%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% log-scores against data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Standardise logscores and data:
tempVARlsH1 = zscore(VAR.ls(:,:,1)) ;
tempTARlsH1 = zscore(TAR.ls(:,:,1)) ;
tempVARlsHm = zscore(VAR.ls(:,:,end)) ;
tempTARlsHm = zscore(TAR.ls(:,:,end)) ;
tempData1   = zscore(dataout);

% Get cumulative data
hh = horizons(end);
tempDataM = NaN*tempData1;
for tt = T0+hh:size(tempData1, 1) 
    tempDataM(tt, :)  = sum(tempData1(tt-hh+1:tt, :), 1);
end

figure('Name', 'LS & data, horizon 1 (all)')
for ii = 1:4
    subplot(2, 2, ii)
    hold on
    plot(tempVARlsH1(:,ii), 'b'), axis tight, title(vnamesvar(ii))
    plot(tempTARlsH1(:,ii), 'r'), axis tight, title(vnamestar(ii))
    plot(tempData1(T0+1:T0+T2, ii), 'k-.')
    hold off
    xlabel('Time')
end
legend('VAR', 'TAR', 'data')

figure('Name', 'LS & data, horizon 1 (IP)')
hold on
plot(tempVARlsH1(:,1), 'b', 'LineWidth', 2), axis square, title(vnamesvar(1))
plot(tempTARlsH1(:,1), 'r', 'LineWidth', 2), axis square, title(vnamestar(1))
plot(tempData1(T0+1:T0+T2, 1), 'k-*')
hold off
xlabel('Time')
legend('VAR', 'TAR', 'data')

figure('Name', 'LS & data, horizon max (IP)')
hold on
plot(tempVARlsHm(:,1), 'b', 'LineWidth', 2), axis square, title(vnamesvar(1))
plot(tempTARlsHm(:,1), 'r', 'LineWidth', 2), axis square, title(vnamestar(1))
plot(tempDataM(T0+hh:end, 1), 'k-*')
hold off
xlabel('Time')
legend('VAR', 'TAR', 'data')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% clean up
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delete temp*
