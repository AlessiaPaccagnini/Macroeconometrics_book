function ST=getst(fprob,p,q)
T=rows(fprob);
ST=zeros(T,1);
%time t
   p00=fprob(T,1);
   p01=fprob(T,2);
   r=rand(1,1);
   ST(T,1)=(r>=p00/(p00+p01));

%time t-1 to 1

for it=T-1:-1:1
pr_tr=[p(it) (1-q(it)); (1-p(it)) q(it)];
if ST(it+1)==0;
p00=pr_tr(1,1)*fprob(it,1);
p01=pr_tr(1,2)*fprob(it,2);
elseif ST(it+1)==1;
p00=pr_tr(2,1)*fprob(it,1);
p01=pr_tr(2,2)*fprob(it,2);
end

%sample regime numbers

       r=rand(1,1);
       if r<p00/(p00+p01);
              ST(it)=0;
       else
              ST(it)=1;
       end

end
