function [fprob,lik]=hamiltonfilter(beta1,beta2,sigma1,sigma2,p,q,y,x)

T=rows(y);
isig1=invpd(sigma1);
isig2=invpd(sigma2);
dsig1=det(sigma1);
dsig2=det(sigma2);
%*******************************************step 2 initialise for filter(ergodic probabiltites)r************************************@
%transition probability matrix

    pr_tr=[p(1) (1-q(1)); (1-p(1)) q(1)];

A = [(eye(2)-pr_tr);ones(1,2)];
 EN=[0;0;1];
 ett= pinv(A'*A)*A'*EN;
 if isnan(ett)==1;
 ett=[0.5;0.5];
 end

%**************************************************Step 1 Filter Forward Iteration*****************@
lik=0;
fprob=zeros(T,2);
for it=1:T
pr_tr=[p(it) (1-q(it)); (1-p(it)) q(it)];
em1=y(it,:)-x(it,:)*beta1;
em2=y(it,:)-x(it,:)*beta2;
neta1=(1/sqrt(dsig1))*exp(-0.5*(em1*isig1*em1'));%F(Y\S=1)
neta2=(1/sqrt(dsig2))*exp(-0.5*(em2*isig2*em2'));%F(Y\S=2)

%hamilton filter kim and Nelson eq 4.19 and 4.20 pg63 also see equations 22.4.5 and 22.4.6 in Hamilton
ett1=ett.*([neta1;neta2]);
fit=sum(ett1);
ett=(pr_tr*ett1)/fit;
fprob(it,:)=(ett1./fit)';
if fit>0
    lik=lik+log(fit);
else
    lik=lik-10;
end
end