function [pmatT,ystar]=getystarF(s,zall,gammax)
T=rows(zall);
ystar=zeros(T,1);
pmatT=zeros(T,4);

 mm=zall*gammax;
 vv=1;

%/////calculate transition probabilities

tempP=-zall(:,1:cols(zall)-1)*gammax(1:rows(gammax)-1);
tempQ=(-zall(:,1:cols(zall)-1)*gammax(1:rows(gammax)-1))-gammax(end);                        

pmatT(:,1)=normcdf(tempP);
pmatT(:,2)=1-pmatT(:,1);
pmatT(:,4)=1-normcdf(tempQ);
pmatT(:,3)=1-pmatT(:,4);


for i=1:T
% mm=zall(i,:)*gammax;
% vv=1;
if s(i)==1
ystar(i)= normlt_rnd(mm(i),vv,0);%draw from left truncated normal
elseif s(i)==0;
ystar(i)= normrt_rnd(mm(i),vv,0); %/draw from right truncated normal
end

end