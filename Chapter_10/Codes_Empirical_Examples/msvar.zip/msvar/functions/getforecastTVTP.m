function [ yhat,psim,qsim ] = getforecastTVTP( VarBench,HORZ,N,Yin,gammax,alpha1,alpha2,sig1,sig2,fprob )


L       = VarBench.L;


varcoef1=reshape(alpha1,N*L+1,N);
varcoef2=reshape(alpha2,N*L+1,N);
A1=chol(sig1);
A2=chol(sig2);




yhat=zeros(HORZ+L,N);
T=rows(Yin);
yhat(1:L,:)=Yin(T-L+1:T,:);
psim=zeros(HORZ+L,1);
qsim=zeros(HORZ+L,1);
ett11=fprob(end,:)';
for i=L+1:rows(yhat)
    zall=1;
    
   
    %project transition probabilities
    tempP=-zall(1)*gammax(1);
tempQ=-zall(1)*gammax(1)-gammax(end);
psim(i)=normcdf(tempP);
qsim(i)=1-normcdf(tempQ);
pr_tr=[psim(i) (1-qsim(i)); (1-psim(i)) qsim(i)];
%project filter probabilitites
ett10=pr_tr*ett11;

xhat=[];
    for j=1:L
        xhat=[xhat yhat(i-j,:)];
    end
    xhat=[xhat 1];
  yhat1=xhat*varcoef1+randn(1,N)*A1;
  yhat2=xhat*varcoef2+randn(1,N)*A2;
  
 yhat(i,:)=(yhat1.*ett10(1))+(yhat2.*ett10(2)); 
 ett11=ett10;
end
end

