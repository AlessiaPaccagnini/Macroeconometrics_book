function [ST,PROBLEM]=getS(fprob,p,q,Ncrit,maxdraws)
PROBLEM=0;
j=1;
chck=-1;
while j<maxdraws && chck<0
    ST=getst(fprob,p,q);
    
    check1=length(unique(ST))==2;
    T1=sum(ST==0);
    T2=sum(ST==1);
    check2=T1>=Ncrit;
    check3=T2>=Ncrit;
    
if check1+check2+check3==3
    chck=10;
else
    j=j+1;
end
end
if check1+check2+check3<3
    PROBLEM=1;
end
