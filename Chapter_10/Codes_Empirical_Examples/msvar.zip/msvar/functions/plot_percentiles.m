%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Point forecasts against data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose a pair of percentiles (ordered as in 'percentiles'):
temppct = [2 4];

figure('Name', 'PCTL & data, horizon 1 (all)')

for ii = 1:N

    % pick 1st and last percentile:
    tempvar = squeeze(VAR.pct(:,ii,1, temppct ));
    temptar = squeeze(TAR.pct(:,ii,1, temppct ));
    
    subplot(2, 2, ii)
    hold on
    plot(tempvar, 'b-', 'LineWidth', 2), axis tight,
    plot(temptar, 'r-', 'LineWidth', 2), axis tight, 
    plot(dataout(T0+1:T0+T2, ii), 'k.', 'LineWidth', 1)
    hold off
    title(vnamestar(ii))
    xlabel('Time')
       
end
legend('VAR', '', 'TAR', '', 'data')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% clean up
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delete temp*
