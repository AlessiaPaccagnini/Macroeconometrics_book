function [bsave1,bsave2,sigmaS1,sigmaS2,gsave,regime,pmat,qmat,fsave]=estimatemstvtp(data,VarBench,s00x,HORZ,REPS,BURN,Update,MaxTrys,dp)


% Redefine paras (just to use shorter names):
L       = VarBench.L;
lamdaP  = VarBench.lamdaP;
tauP    = VarBench.tauP;
epsilonP= VarBench.epsilonP;
tvtpc=VarBench.TVTPpriorC;       %prior mean for constants in prob equation
tvtpvarc=VarBench.TVTPpriorvarC;       %prior variance for constants in prob equation

% Get input data    


Y=data;
N=cols(Y);
ncrit=(N*L+1);

%take lags
X=[];
for j=1:L
X=[X lag0(Y,j) ];
end
X=[X ones(rows(X),1)];



dataz=[];
tvtpb=[];
tvtpvarb=[];

tvtpd=L;

Y=Y(max([L,max(tvtpd)])+1:end,:);
X=X(max([L,max(tvtpd)])+1:end,:);
if ~isempty(dataz)
dataz=dataz(max([L,max(tvtpd)])+1:end,:);
end
NZ=cols(dataz);
T=rows(Y);


% Additional priors for VAR coefficients
muP=mean(Y)';
sigmaP=[];
deltaP=[];
e0=[];
for i=1:N
    ytemp=Y(:,i);
    xtemp=[lag0(ytemp,1) ones(rows(ytemp),1)];
    ytemp=ytemp(2:end,:);
    xtemp=xtemp(2:end,:);
    btemp=xtemp\ytemp;
    etemp=ytemp-xtemp*btemp;
    stemp=etemp'*etemp/rows(ytemp);
    if abs(btemp(1))>1
        btemp(1)=1;
    end
    deltaP=[deltaP;btemp(1)];
    sigmaP=[sigmaP;stemp];
    e0=[e0 etemp];
end

%dummy data to implement priors see http://ideas.repec.org/p/ecb/ecbwps/20080966.html
[yd,xd] = create_dummies(lamdaP,tauP,deltaP,epsilonP,L,muP,sigmaP,N);

%set priors for transition probability equation

g0=tvtpc(1);
if length(tvtpb)==1
    for i=1:NZ
    g0=[g0;tvtpb(1)];
    end
else
    g0=[g0;tvtpb];
end
g0=[g0;tvtpc(2)];


ivg0=tvtpvarc(1);
if length(tvtpvarb)==1
    for i=1:NZ
    ivg0=[ivg0;tvtpvarb(1)];
    end
else
    ivg0=[ivg0;tvtpvarb];
end
ivg0=[ivg0;tvtpvarc(2)];
ivg0=inv(diag(ivg0));

%starting values to intialise the Gibbs algorithm
si=s00x(1:T);
s00=si;
ppnew=ones(T,1).*0.95;
qqnew=ones(T,1).*0.95;
ymat1=Y(si==0,:);
xmat1=X(si==0,:);
btemp1=xmat1\ymat1;
etemp1=ymat1-xmat1*btemp1;
sig1=(etemp1'*etemp1)/rows(etemp1);

ymat2=Y(si==1,:);
xmat2=X(si==1,:);
btemp2=xmat2\ymat2;
etemp2=ymat2-xmat2*btemp2;
sig2=(etemp2'*etemp2)/rows(etemp2);
alpha1=btemp1;
alpha2=btemp2;
alpha00=[vec(btemp1)' vec(btemp2)'];
alpha1=vec(alpha1);
alpha2=vec(alpha2);
gammax=g0;




fsave=zeros(REPS-BURN,HORZ,N); 

   
   bsave1=zeros(REPS-BURN,N*(N*L+1));
   bsave2=zeros(REPS-BURN,N*(N*L+1));
   sigmaS1=zeros(REPS-BURN,N,N);
   sigmaS2=zeros(REPS-BURN,N,N);
   gsave=zeros(REPS-BURN,rows(g0));
   regime=zeros(REPS-BURN,T);
   pmat=regime;
   qmat=regime;
   lik=zeros(REPS-BURN,1);


igibbs=1;
  jgibbs=0;
while jgibbs<REPS-BURN
problems=0;
problems1=0;
%step 1 : Draw St
varcoef1=reshape(alpha1,N*L+1,N);
varcoef2=reshape(alpha2,N*L+1,N);
 [fprob,liki]=hamiltonfilter(varcoef1,varcoef2,sig1,sig2,ppnew,qqnew,Y,X);
 
 [si,problems]=getS(fprob,ppnew,qqnew,ncrit,MaxTrys);
 if problems
   si=s00;
 else
     s00=si;
 end
 slag=lag0(si,1); %S(-1)
 
%step 2: Draw Ystar the latent variable
if NZ>0
zall=[ones(rows(Y),1) dataz slag];
zall=zall(2:end,:);
zall=[zall(1,:);zall];
else
 zall=[ones(rows(Y),1)  slag];
zall=zall(2:end,:);
zall=[zall(1,:);zall]; 
end
% tic
% [pmatall,ys]=getystar(si,zall,gammax,NZ);
% toc


[pmatall,ys]=getystarF(si,zall,gammax);


ppnew=pmatall(:,1);
qqnew=pmatall(:,4);

trys=1;
chck=-1;
while chck<0 && trys<MaxTrys
%draw VAR coefficients

ymat1=Y(si==0,:);
xmat1=X(si==0,:);

ymat2=Y(si==1,:);
xmat2=X(si==1,:);

Y01=[ymat1;yd];
    X01=[xmat1;xd];
  %conditional mean of the VAR coefficients
  mstar1=vec(X01\Y01);  %ols on the appended data
  xx=X01'*X01;
  ixx1=xx\eye(cols(xx));
   [ alpha1,problems1] = getcoef( mstar1,sig1,ixx1,MaxTrys,N,L );
     
     
     
     Y02=[ymat2;yd];
    X02=[xmat2;xd];
  %conditional mean of the VAR coefficients
  mstar2=vec(X02\Y02);  %ols on the appended data
  xx=X02'*X02;
  ixx2=xx\eye(cols(xx));
   [ alpha2,problems1] = getcoef( mstar2,sig2,ixx2,MaxTrys,N,L );
     if problems1
         alpha2=alpha00(:,N*(N*L+1)+1:end);
     else
         alpha00(:,N*(N*L+1)+1:end)=alpha2';
     end
     
     [m1,m2]=getmeans(alpha1,alpha2,N,L);
     if m1(1)<m2(1)
         chck=1;
     else
         trys=trys+1;
     end
end
     
  if chck<0
      problems1=1;
      alpha1=alpha00(:,1:N*(N*L+1));
      alpha2=alpha00(:,N*(N*L+1)+1:end);
  else
     alpha00(:,1:N*(N*L+1))=alpha1'; 
     alpha00(:,N*(N*L+1)+1:end)=alpha2';
  end
     
%      disp(num2str([m1(1) m2(1)]))
     
     
     
   %draw VAR covariance 
  
     evar1=Y01-X01*reshape(alpha1,N*L+1,N);
     scale1=evar1'*evar1;
    sig1=iwpq(rows(Y01),invpd(scale1));  
    
    
     evar2=Y02-X02*reshape(alpha2,N*L+1,N);
     scale2=evar2'*evar2;
    sig2=iwpq(rows(Y02),invpd(scale2));  
    

    %draw Gammax
    
    xs=[ones(T,1) dataz slag];
    xs=xs(2:end,:);
    ys=ys(2:end,:);
    [gammax]=getreg1(ys,xs,g0,ivg0,1);
    
    
    if dp
    % Display progress:
    if mod(igibbs,Update)==0 
        disp(sprintf('    Replication %s of %s  gamma %s problem %s' , ... 
             num2str(igibbs), num2str(REPS),num2str(gammax(2)),num2str([problems problems1])));
    end  
    end
    
    
    if igibbs>BURN && ~problems &&~ problems1
         jgibbs=jgibbs+1;
         % Simulate and store forward paths:

[ yhat,psim,qsim ] = getforecastTVTP( VarBench,HORZ,N,Y,gammax,alpha1,alpha2,sig1,sig2,fprob )
 fsave(jgibbs,:,:)=yhat(L+1:end,:);
     
    bsave1(jgibbs,:)=alpha1';
   bsave2(jgibbs,:)=alpha2';
   sigmaS1(jgibbs,:,:)=sig1;
   sigmaS2(jgibbs,:,:)=sig2;   
   gsave(jgibbs,:)=[gammax'];
   regime(jgibbs,:)=si';
   pmat(jgibbs,:)=ppnew';
   qmat(jgibbs,:)=qqnew';
   lik(jgibbs)=liki;
   


     end
     igibbs=igibbs+1;
end


