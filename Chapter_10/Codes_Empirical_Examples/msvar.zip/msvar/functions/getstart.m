function [ s00x ] = getstart( data,L,reps )

Y=data;
%take lags
X=[];
for j=1:L
X=[X lag0(Y,j) ];
end
X=[X ones(rows(X),1)];
Y=Y(L+1:end,:);
X=X(L+1:end,:);
N=cols(Y);
bols=X\Y;
bols1=[bols(1:N*L,:);abs(bols(N*L+1,:))*-1];
e=Y-X*bols;
sig1=(e'*e)/(rows(X)-cols(X));
sig2=sig1/10;
A1=vecr(chol(sig1)');
A2=vecr(chol(sig2)');
A1=A1(A1~=0);
A2=A2(A2~=0);
theta0=[vec(bols1);vec(bols);A1;A2;4;4];
 [fval,theta2,gh,hess,itct,fcount,retcodeh] = csminwel('hamiltonfilterML',theta0,eye(length(theta0))*.5,[],1e-15,reps,Y,X,N,L);
 [lik,fprob,m1,m2,sig1,sig2]=hamiltonfilterML(theta2,Y,X,cols(Y),L);
if sig2(1)<sig1(1);
s00x=fprob(:,2)>0.5;
else
s00x=fprob(:,1)>0.5;
end


end

