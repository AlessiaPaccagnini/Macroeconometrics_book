function [pmatT,ystar]=getystar(s,zall,gammax,NZ)
T=rows(zall);
ystar=zeros(T,1);
pmatT=zeros(T,4);

for i=1:T
mm=zall(i,:)*gammax;
vv=1;
if s(i)==1
ystar(i)= normlt_rnd(mm,vv,0);%draw from left truncated normal
elseif s(i)==0;
ystar(i)= normrt_rnd(mm,vv,0); %/draw from right truncated normal
end
%/////calculate transition probabilities
if NZ>0
tempP=-zall(i,1)*gammax(1)-zall(i,2:cols(zall)-1)*gammax(2:rows(gammax)-1);
tempQ=-zall(i,1)*gammax(1)-zall(i,2:cols(zall)-1)*gammax(2:rows(gammax)-1)-gammax(rows(gammax));
else
tempP=-zall(i,1)*gammax(1);
tempQ=-zall(i,1)*gammax(1)-gammax(rows(gammax));
end
pmatT(i,1)=normcdf(tempP);
pmatT(i,2)=1-pmatT(i,1);
pmatT(i,4)=1-normcdf(tempQ);
pmatT(i,3)=1-pmatT(i,4);
end