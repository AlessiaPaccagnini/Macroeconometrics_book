function [m1,m2]=getmeans(beta1,beta2,N,L)
[ FF1,MU1,QQ1] = comp(beta1,eye(N),N,L);
[ FF2,MU2,QQ2] = comp(beta2,eye(N),N,L);
m1=inv(eye(cols(FF1))-FF1)*MU1';
m2=inv(eye(cols(FF2))-FF2)*MU2';