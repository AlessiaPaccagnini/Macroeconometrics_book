% =========================================================================
% Author  : Haroon Mumtaz
% Website : https://sites.google.com/site/hmumtaz77/home
% =========================================================================
% Markov-Switching VAR with Time-Varying Transition Probabilities (MS-VAR-TVTP)
% Gibbs sampler via estimatemstvtpnew()
% Compatible with Mac, Linux, and Windows
% =========================================================================

clear;

% --- Path setup (cross-platform) -----------------------------------------
strFolder = fullfile(pwd, filesep);
addpath(fullfile(pwd, 'functions'));

% --- Load data (cross-platform) ------------------------------------------
data = xlsread(fullfile(pwd, 'data', 'ukdata.xls'));

% --- Gibbs sampling settings ---------------------------------------------
REPS   = 20000;
BURN   = 15000;
Update = 100;
MaxTrys = 1000;
HORZ   = 12;

% --- Prior settings -------------------------------------------------------
L        = 4;
lamdaP   = 0.1;
tauP     = 10 * lamdaP;
epsilonP = 1 / 1000;
tvtpc    = [-2; -4];    % prior mean for constants in probability equation
tvtpvarc = [10; 10];    % prior variance for constants in probability equation
dp       = 1;           % 1 to display progress

% --- Pack settings into VarBench struct ----------------------------------
VarBench.L            = L;
VarBench.lamdaP       = lamdaP;
VarBench.tauP         = tauP;
VarBench.epsilonP     = epsilonP;
VarBench.TVTPpriorC   = tvtpc;
VarBench.TVTPpriorvarC = tvtpvarc;

% --- Run Gibbs sampler ---------------------------------------------------
[bsave1, bsave2, sigmaS1, sigmaS2, gsave, regime, pmat, qmat, fsave] = ...
    estimatemstvtpnew(data, VarBench, HORZ, REPS, BURN, Update, MaxTrys, dp);

% --- Output description --------------------------------------------------
% bsave1   : Regime 1 coefficients  -- Gibbs x 1 x (N*L+1)
% bsave2   : Regime 2 coefficients  -- Gibbs x 1 x (N*L+1)
% sigmaS1  : Regime 1 covariance    -- Gibbs x N x N
% sigmaS2  : Regime 2 covariance    -- Gibbs x N x N
% gsave    : Probability equation parameters -- Gibbs x (cols(dataz)+2)
%            first column  = constant in regime 1
%            last column   = constant in regime 2
% regime   : State vector S[t]      -- Gibbs x T
% pmat     : P(0|0)                 -- Gibbs x T
% qmat     : P(1|1)                 -- Gibbs x T
% fsave    : Forecast density       -- Gibbs x Horizon x N
