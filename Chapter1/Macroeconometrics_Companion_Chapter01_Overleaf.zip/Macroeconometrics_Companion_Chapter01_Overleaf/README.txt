Macroeconometrics - Chapter 1 Companion Slides
Alessia Paccagnini, De Gruyter, 2026

OVERLEAF
1. Upload this entire folder (or the ZIP package) to a new Overleaf project.
2. Set main.tex as the Main document if Overleaf does not select it automatically.
3. Compile with pdfLaTeX.

The figures in figures/ are drawn from the author's Chapter 1 source package, with the supplied book-cover image used on the title slide.
