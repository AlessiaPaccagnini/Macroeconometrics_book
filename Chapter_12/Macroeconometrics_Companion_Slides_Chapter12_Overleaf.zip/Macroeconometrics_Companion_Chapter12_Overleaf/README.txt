Macroeconometrics - Companion Slides - Chapter 12
Quantile Regression and Growth-at-Risk
Alessia Paccagnini, De Gruyter, 2026

Upload this folder (or the ZIP) to Overleaf and compile main.tex with pdfLaTeX.
The project uses the original high-resolution/vector figures from the book source.
The slides are intended as an editable teaching starting point.
