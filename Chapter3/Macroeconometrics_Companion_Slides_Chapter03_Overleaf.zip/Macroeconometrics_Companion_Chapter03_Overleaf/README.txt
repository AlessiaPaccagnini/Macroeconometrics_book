Macroeconometrics - Chapter 3 Companion Slides
Alessia Paccagnini, De Gruyter, 2026

Upload this ZIP directly to Overleaf and compile main.tex with pdfLaTeX.
The deck is intentionally a flexible teaching starting point: users are encouraged to add examples, applications, exercises, and discussion material.
