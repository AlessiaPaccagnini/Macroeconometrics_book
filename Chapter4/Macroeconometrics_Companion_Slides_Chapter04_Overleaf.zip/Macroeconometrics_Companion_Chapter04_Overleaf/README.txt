Macroeconometrics - Chapter 4 Companion Slides
Alessia Paccagnini, De Gruyter, 2026

Upload this folder (or the ZIP) to Overleaf and compile main.tex with pdfLaTeX.
The slides are intentionally designed as an editable teaching starting point.
