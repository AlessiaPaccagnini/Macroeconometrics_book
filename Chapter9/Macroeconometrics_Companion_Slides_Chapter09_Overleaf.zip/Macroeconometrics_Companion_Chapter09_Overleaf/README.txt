Macroeconometrics - Chapter 9 Companion Slides
Alessia Paccagnini, De Gruyter, 2026

Upload this folder/ZIP to Overleaf and compile main.tex with pdfLaTeX.
Original Chapter 9 figures from the book source are included in figures/.
These slides are designed as an editable teaching starting point.
