Macroeconometrics Companion Slides — Chapter 8: High Dimensionality
Alessia Paccagnini, De Gruyter, 2026

Upload this folder/ZIP to Overleaf and compile main.tex with pdfLaTeX.
Original vector PDF figures from the book source are retained for high-resolution rendering.
The slides are intended as an editable teaching starting point.
