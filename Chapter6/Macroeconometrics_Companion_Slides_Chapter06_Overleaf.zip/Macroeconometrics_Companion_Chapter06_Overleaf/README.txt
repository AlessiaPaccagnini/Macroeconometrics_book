Macroeconometrics Companion Slides - Chapter 6: DSGE Models
Alessia Paccagnini, De Gruyter, 2026

Upload this folder/ZIP to Overleaf and compile main.tex with pdfLaTeX.
The slides are designed as an editable teaching starting point.
