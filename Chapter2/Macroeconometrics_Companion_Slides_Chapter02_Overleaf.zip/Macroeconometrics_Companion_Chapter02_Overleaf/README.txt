Macroeconometrics - Chapter 2 Companion Slides
Alessia Paccagnini, De Gruyter, 2026

Upload this complete folder/ZIP to Overleaf and compile main.tex with pdfLaTeX.
The figures are taken from the Chapter 2 source materials supplied with the book project.
