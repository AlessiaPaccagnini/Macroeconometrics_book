Macroeconometrics - Companion Slides - Chapter 5: Bayesian Estimation
Alessia Paccagnini, De Gruyter, 2026

Upload this folder (or the supplied ZIP) to Overleaf and compile main.tex with pdfLaTeX.
The slides are intentionally designed as an editable teaching starting point.
